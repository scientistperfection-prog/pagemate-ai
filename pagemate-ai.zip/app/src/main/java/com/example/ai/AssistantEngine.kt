package com.example.ai

import com.example.data.models.EmojiLevel
import com.example.data.models.LanguageMode
import com.example.data.models.PersonalityConfigEntity
import com.example.data.models.ReplyLength
import com.example.data.models.ToneStyle

data class AiResponseResult(
    val replyText: String,
    val confidence: Float,
    val detectedIntent: String,
    val detectedLanguage: String,
    val requiresHumanHandoff: Boolean,
    val handoffReason: String = "",
    val extractedFacts: List<Pair<String, String>> = emptyList() // Category to Fact
)

object AssistantEngine {

    fun processMessage(
        userMessage: String,
        config: PersonalityConfigEntity,
        conversationMemory: List<String> = emptyList()
    ): AiResponseResult {
        val cleanMsg = userMessage.trim()
        val lower = cleanMsg.lowercase()

        val detectedLang = detectLanguage(cleanMsg, config.primaryLanguage)
        val isHumanRequest = checkHumanRequest(lower)
        val isFrustrated = checkFrustration(lower)

        // 1. Human handoff condition checking
        if (isHumanRequest) {
            val handoffText = when (detectedLang) {
                "Bangla" -> "অবশ্যই! আমি পেইজের মানব ওনারের কাছে হস্তান্তর করছি। কিছুক্ষণের মধ্যেই উনি সরাসরি আপনার সাথে মেসেঞ্জারে যুক্ত হবেন। ধন্যবাদ আপনার ধৈর্যের জন্য! 🙏"
                "Banglish" -> "Sure bhai! Ami page owner ke notify korechi. Kichukkhoner moddhe tini apnar shathe direct kotha bolben. Dhonnobad apnar patience er jonno! 🙏"
                else -> "Certainly! I am alerting the human page owner. They will take over this conversation shortly. Thank you for your patience! 🙏"
            }
            return AiResponseResult(
                replyText = handoffText,
                confidence = 0.98f,
                detectedIntent = "Human Agent Request",
                detectedLanguage = detectedLang,
                requiresHumanHandoff = true,
                handoffReason = "Customer explicitly requested human assistance."
            )
        }

        if (isFrustrated) {
            val frustratedHandoffText = when (detectedLang) {
                "Bangla" -> "আমরা অত্যন্ত দুঃখিত আপনার এই অসুবিধার জন্য! 🙏 বিষয়টি বিশেষ গুরুত্ব দিয়ে দেখার জন্য আমি পেইজের মানব ওনারকে সাথে সাথে যুক্ত করছি। উনি দ্রুত সমাধান দিচ্ছেন।"
                "Banglish" -> "Khub e dukhito apnar ei problem er jonno! 🙏 Shomoshya ta urgent dekhar jonno ami direct owner ke connect kore dicchi. Tini ekhon e solve kore diben."
                else -> "We sincerely apologize for this inconvenience! 🙏 I am escalating this immediately to the page owner for urgent human review."
            }
            return AiResponseResult(
                replyText = frustratedHandoffText,
                confidence = 0.55f,
                detectedIntent = "Customer Frustration Detected",
                detectedLanguage = detectedLang,
                requiresHumanHandoff = true,
                handoffReason = "Customer sentiment indicates frustration or service complaint."
            )
        }

        // 2. Extract context facts for memory
        val facts = extractVoluntaryFacts(cleanMsg)

        // 3. Intent Detection & Response Construction
        val (intent, baseReply, confidence) = when {
            containsAny(lower, "delivery", "charge", "dam", "price", "taka", "koto", "খরচ", "ডেলিভারি", "টাকা", "চার্জ", "ক্যাশ অন", "cod") -> {
                Triple("Pricing & Delivery", buildDeliveryReply(detectedLang, config), 0.96f)
            }
            containsAny(lower, "order", "parcel", "track", "status", "অর্ডার", "পার্সেল", "কোথায়", "পৌঁছাবে", "kobe pabo") -> {
                Triple("Order Inquiry", buildOrderReply(detectedLang, config), 0.92f)
            }
            containsAny(lower, "quality", "original", "guarantee", "warranty", "গ্যারান্টি", "ওয়ারেন্টি", "আসল", "রং", "কালার", "size", "সাইজ", "stock", "available") -> {
                Triple("Product Details", buildProductReply(detectedLang, config), 0.94f)
            }
            containsAny(lower, "hi", "hello", "salam", "assalam", "হাই", "হ্যালো", "সালাম", "hey", "valo", "কেমন আছেন") -> {
                Triple("Greeting", buildGreetingReply(detectedLang, config), 0.99f)
            }
            containsAny(lower, "location", "shop", "address", "thikana", "ঠিকানা", "দোকান", "কোথায়") -> {
                Triple("Business Address", buildAddressReply(detectedLang, config), 0.95f)
            }
            containsAny(lower, "discount", "offer", "kom hobe", "ছাড়", "কম রাখবেন") -> {
                Triple("Discount Inquiry", buildDiscountReply(detectedLang, config), 0.88f)
            }
            else -> {
                // Unknown / Complex query -> lower confidence
                Triple("General Inquiry", buildGeneralReply(cleanMsg, detectedLang, config), 0.70f)
            }
        }

        val requiresHandoff = confidence < 0.75f
        val reason = if (requiresHandoff) "AI confidence below threshold (70%); complex topic requires owner judgment." else ""

        val formattedReply = applyPersonalityStyling(baseReply, config)

        return AiResponseResult(
            replyText = formattedReply,
            confidence = confidence,
            detectedIntent = intent,
            detectedLanguage = detectedLang,
            requiresHumanHandoff = requiresHandoff,
            handoffReason = reason,
            extractedFacts = facts
        )
    }

    private fun detectLanguage(text: String, preference: LanguageMode): String {
        if (preference == LanguageMode.BANGLA) return "Bangla"
        if (preference == LanguageMode.BANGLISH) return "Banglish"
        if (preference == LanguageMode.ENGLISH) return "English"

        // Auto detection
        val hasBanglaScript = text.any { it.code in 0x0980..0x09FF }
        if (hasBanglaScript) return "Bangla"

        val lower = text.lowercase()
        val banglishTokens = listOf(
            "bhai", "koto", "pabo", "shathe", "kemon", "ache", "hobe", "hobey",
            "korbo", "ekhon", "dorkar", "dam", "parbo", "apnar", "amader", "kotha",
            "chai", "dhaka", "jante", "jani", "bhalo"
        )
        val banglishScore = banglishTokens.count { lower.contains(it) }
        if (banglishScore >= 1) return "Banglish"

        return "English"
    }

    private fun checkHumanRequest(text: String): Boolean {
        val triggers = listOf(
            "human", "owner", "admin", "real person", "agent", "support person",
            "manush", "manusher", "মানুষের সাথে", "ওনার", "মালিক", "লাইভ এজেন্ট",
            "কথা বলতে চাই", "kotha bolte chai", "talk to human", "call me",
            "bhai owner", "ai bondho", "stop bot", "transfer"
        )
        return triggers.any { text.contains(it) }
    }

    private fun checkFrustration(text: String): Boolean {
        val triggers = listOf(
            "baje", "faltu", "kharap", "scam", "chori", "dhoka", "fraud",
            "angry", "worst", "useless", "terrible", "খারাপ", "বাজে সার্ভিস",
            "প্রতারক", "ভুয়া", "dhokabaj", "cheat"
        )
        return triggers.any { text.contains(it) }
    }

    private fun extractVoluntaryFacts(text: String): List<Pair<String, String>> {
        val facts = mutableListOf<Pair<String, String>>()
        val lower = text.lowercase()

        // Location voluntary info
        if (lower.contains("chittagong") || lower.contains("ctg") || lower.contains("চট্টগ্রাম")) {
            facts.add("Preference" to "Customer Location: Chittagong")
        } else if (lower.contains("dhaka") || lower.contains("ঢাকা") || lower.contains("uttara") || lower.contains("dhanmondi")) {
            facts.add("Preference" to "Customer Location: Dhaka area")
        } else if (lower.contains("sylhet") || lower.contains("সিলেট")) {
            facts.add("Preference" to "Customer Location: Sylhet")
        }

        // Payment preference voluntary info
        if (lower.contains("cash on delivery") || lower.contains("cod") || lower.contains("ক্যাশ অন")) {
            facts.add("Preference" to "Prefers Cash on Delivery (COD)")
        } else if (lower.contains("bkash") || lower.contains("বিকাশ") || lower.contains("nagad")) {
            facts.add("Preference" to "Inquired about bKash/Nagad direct payment")
        }

        // Product size/interest
        if (lower.contains("size xl") || lower.contains("xl")) {
            facts.add("Pending Request" to "Requested Size: XL")
        } else if (lower.contains("size l") || lower.contains("large")) {
            facts.add("Pending Request" to "Requested Size: Large")
        }

        return facts
    }

    private fun buildDeliveryReply(lang: String, config: PersonalityConfigEntity): String {
        return when (lang) {
            "Bangla" -> "আমাদের ঢাকা সিটির ভেতর হোম ডেলিভারি চার্জ ৬০ টাকা এবং ঢাকার বাইরে ১২০ টাকা। সারাদেশে ক্যাশ অন ডেলিভারি (COD) সুবিধা রয়েছে। ঢাকার ভেতর ২৪-৪৮ ঘণ্টার মধ্যে ও বাইরে ২-৩ কর্মদিবসে পার্সেল পৌঁছে যাবে।"
            "Banglish" -> "Amader Dhaka city te delivery charge 60 taka and Dhakar baire 120 taka. Cash on delivery available everywhere in BD! Dhakay 24-48 hours and baire 2-3 diner moddhe delivery hoye thake."
            else -> "Our home delivery charge is 60 BDT inside Dhaka city and 120 BDT outside Dhaka. Cash on delivery is available nationwide! Delivery takes 24-48 hours within Dhaka and 2-3 business days across Bangladesh."
        }
    }

    private fun buildOrderReply(lang: String, config: PersonalityConfigEntity): String {
        return when (lang) {
            "Bangla" -> "অর্ডার করার জন্য আপনার নাম, পূর্ণ ডেলিভারি ঠিকানা এবং ফোন নম্বর লিখে পাঠাবেন। আমাদের টিম অর্ডারটি কনফার্ম করে ট্র্যাকিং আইডি প্রদান করবে।"
            "Banglish" -> "Order confirm korar jonno apnar Name, full Address and Phone number inbox korun. Amra order create kore apnake invoice and tracking code pathiye dibo!"
            else -> "To place or check an order, please share your full Name, Delivery Address, and Contact Number. Our team will verify and send your tracking details immediately."
        }
    }

    private fun buildProductReply(lang: String, config: PersonalityConfigEntity): String {
        return when (lang) {
            "Bangla" -> "আমাদের সকল প্রোডাক্ট ১০০% অরিজিনাল ও প্রিমিয়াম কোয়ালিটি নিশ্চিত করা। প্রতিটি প্রোডাক্টে ৭ দিনের রিপ্লেসমেন্ট এবং অফিসিয়াল ওয়ারেন্টি সুবিধা রয়েছে। নির্দিষ্ট কোনো কালার বা সাইজ কি আপনার পছন্দ আছে?"
            "Banglish" -> "Amader shob item 100% original and premium grade quality. 7 days easy replacement and warranty included! Apnar specific kon model ba color ta pochondo?"
            else -> "All our products are 100% genuine with verified quality checks, backed by a 7-day hassle-free replacement warranty. Would you like to know more about a specific model or color?"
        }
    }

    private fun buildGreetingReply(lang: String, config: PersonalityConfigEntity): String {
        val assistantIntro = "আমি ${config.assistantName}"
        return when (lang) {
            "Bangla" -> "হ্যালো! $assistantIntro। আমাদের পেজে আপনাকে স্বাগতম! আজ আপনাকে কী তথ্য দিয়ে সাহায্য করতে পারি?"
            "Banglish" -> "Hello! $assistantIntro speaking. Amader page e welcome! Aaj apnake kivabe help korte pari?"
            else -> "Hello! I am ${config.assistantName}. Welcome to our official page! How may I assist you today?"
        }
    }

    private fun buildAddressReply(lang: String, config: PersonalityConfigEntity): String {
        return when (lang) {
            "Bangla" -> "আমাদের প্রধান ডিসপ্লে ও পিকআপ পয়েন্ট: ধানমন্ডি ২৭, ঢাকা ১২০৯। প্রতিদিন সকাল ১০টা থেকে রাত ৮টা পর্যন্ত খোলা থাকে।"
            "Banglish" -> "Amader display showroom: Dhanmondi 27, Dhaka 1209. Protidin 10 AM theke 8 PM porjonto open thake. Showroom theke direct pickup o korte parben!"
            else -> "Our display and pickup showroom is located at Dhanmondi 27, Dhaka 1209. Open daily from 10:00 AM to 8:00 PM."
        }
    }

    private fun buildDiscountReply(lang: String, config: PersonalityConfigEntity): String {
        return when (lang) {
            "Bangla" -> "আমরা সবসময় সেরা প্রাইস নিশ্চিত করি। বর্তমানে আমাদের নির্দিষ্ট আইটেমে সর্বোচ্চ ১০% স্পেশাল ভাউচার ছাড় চলছে। আপনি কোন আইটেমটি অর্ডার করতে চান জানাবেন?"
            "Banglish" -> "Amra always best budget friendly price offer kori. Currently selected product e up to 10% instant discount cholche. Kon item ti apnar pochondo?"
            else -> "We maintain the best possible pricing directly from verified sources. We currently offer up to 10% seasonal discount on selected items."
        }
    }

    private fun buildGeneralReply(message: String, lang: String, config: PersonalityConfigEntity): String {
        return when (lang) {
            "Bangla" -> "আপনার বার্তাটি পেয়েছি: \"$message\"। আমাদের সেবা সংক্রান্ত আর কোনো বিশেষ তথ্য জানার থাকলে জানান, অথবা আমি ওনারকে অবহিত করতে পারি।"
            "Banglish" -> "Apnar message peyechi: \"$message\"। Aro details jante inbox e likhun ba owner er shathe kotha bolte chaile janan."
            else -> "Thank you for your message regarding: \"$message\". Please feel free to ask about our catalog, pricing, or request human support."
        }
    }

    private fun applyPersonalityStyling(baseText: String, config: PersonalityConfigEntity): String {
        var styled = baseText

        // Tone adjustments
        if (config.toneStyle == ToneStyle.CASUAL && !styled.contains("brother") && !styled.contains("bhai")) {
            styled = styled.replace("হ্যালো!", "হ্যালো ভাইয়া!")
                .replace("Hello!", "Hey there!")
        }

        // Length adjustments
        if (config.replyLength == ReplyLength.SHORT) {
            val sentences = styled.split(". ", "। ")
            if (sentences.size > 2) {
                styled = sentences.take(2).joinToString("। ")
            }
        }

        // Emoji adjustments
        styled = when (config.emojiLevel) {
            EmojiLevel.NONE -> styled.replace(Regex("[\\p{So}\\p{Cn}]"), "").trim()
            EmojiLevel.MODERATE -> {
                if (!styled.contains("😊") && !styled.contains("🙏")) "$styled 😊" else styled
            }
            EmojiLevel.EXPRESSIVE -> {
                if (!styled.contains("✨")) "$styled ✨🛍️" else styled
            }
        }

        return styled
    }

    private fun containsAny(source: String, vararg targets: String): Boolean {
        return targets.any { source.contains(it) }
    }
}
