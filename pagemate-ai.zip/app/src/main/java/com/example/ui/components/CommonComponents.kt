package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ContactLabel
import com.example.ui.theme.AiPurple
import com.example.ui.theme.AiPurpleLight
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MetaBlue
import com.example.ui.theme.MetaLightBlue
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber

@Composable
fun ContactLabelBadge(
    label: ContactLabel,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor) = when (label) {
        ContactLabel.NEEDS_HUMAN_REPLY -> Color(0xFFFEE2E2) to ErrorRed
        ContactLabel.CUSTOMER -> MetaLightBlue to MetaBlue
        ContactLabel.IMPORTANT -> Color(0xFFFEF3C7) to Color(0xFFB45309)
        ContactLabel.FRIEND -> Color(0xFFDCFCE7) to SuccessGreen
        ContactLabel.FOLLOW_UP -> AiPurpleLight to AiPurple
        ContactLabel.NEW_CONTACT -> Color(0xFFF1F5F9) to Color(0xFF475569)
        ContactLabel.ALL -> Color(0xFFF1F5F9) to Color(0xFF475569)
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            if (label == ContactLabel.NEEDS_HUMAN_REPLY) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = textColor,
                    modifier = Modifier.size(11.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
            }
            Text(
                text = label.displayName,
                color = textColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun StatusPill(
    isHumanTakeover: Boolean,
    isNeedsHuman: Boolean,
    modifier: Modifier = Modifier
) {
    val (text, icon, bg, contentCol) = when {
        isNeedsHuman -> Quadruple(
            "Needs Human",
            Icons.Default.Warning,
            Color(0xFFFEE2E2),
            ErrorRed
        )
        isHumanTakeover -> Quadruple(
            "Human Takeover",
            Icons.Default.Person,
            AiPurpleLight,
            AiPurple
        )
        else -> Quadruple(
            "AI Active",
            Icons.Default.AutoAwesome,
            MetaLightBlue,
            MetaBlue
        )
    }

    Surface(
        color = bg,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = contentCol,
                modifier = Modifier.size(11.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = text,
                color = contentCol,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@Composable
fun UserAvatar(
    name: String,
    modifier: Modifier = Modifier,
    size: Int = 44,
    showOnlineBadge: Boolean = true
) {
    val initials = name.split(" ")
        .mapNotNull { it.firstOrNull()?.toString() }
        .take(2)
        .joinToString("")
        .ifBlank { "U" }

    // Color based on name hash
    val colors = listOf(
        MetaBlue,
        AiPurple,
        Color(0xFF0284C7),
        Color(0xFF0D9488),
        Color(0xFFE11D48),
        Color(0xFFD97706)
    )
    val avatarBg = colors[kotlin.math.abs(name.hashCode()) % colors.size]

    Box(modifier = modifier.size(size.dp)) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(size.dp)
                .clip(CircleShape)
                .background(avatarBg)
        ) {
            Text(
                text = initials.uppercase(),
                color = Color.White,
                fontSize = (size * 0.38).sp,
                fontWeight = FontWeight.Bold
            )
        }
        if (showOnlineBadge) {
            Box(
                modifier = Modifier
                    .size((size * 0.28).dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .padding(1.5.dp)
                    .clip(CircleShape)
                    .background(SuccessGreen)
                    .align(Alignment.BottomEnd)
            )
        }
    }
}
