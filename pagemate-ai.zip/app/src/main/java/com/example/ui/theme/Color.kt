package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Meta Messenger & AI palette
val MetaBlue = Color(0xFF0084FF)
val MetaDarkBlue = Color(0xFF0052CC)
val MetaLightBlue = Color(0xFFE7F3FF)
val MetaNavy = Color(0xFF0E1E38)

val AiPurple = Color(0xFF7C3AED)
val AiPurpleLight = Color(0xFFF3E8FF)

val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)

val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)

