package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.models.AppNotificationEntity
import com.example.data.models.ContactLabel
import com.example.data.models.ConversationEntity
import com.example.data.models.FriendReviewEntity
import com.example.data.models.MemoryFactEntity
import com.example.data.models.MessageEntity
import com.example.data.models.PageConnectionEntity
import com.example.data.models.PersonalityConfigEntity
import com.example.data.models.ReviewStatus
import com.example.data.repository.AppRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository.getInstance(application)

    val pageConnection: StateFlow<PageConnectionEntity?> = repository.pageConnectionFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val personalityConfig: StateFlow<PersonalityConfigEntity?> = repository.personalityFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val unreadNotifsCount: StateFlow<Int> = repository.unreadNotifsCountFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val notifications: StateFlow<List<AppNotificationEntity>> = repository.notificationsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val friendReviews: StateFlow<List<FriendReviewEntity>> = repository.friendReviewsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search and label filtering
    val selectedFilterLabel = MutableStateFlow(ContactLabel.ALL)
    val searchQuery = MutableStateFlow("")

    val filteredConversations: StateFlow<List<ConversationEntity>> = combine(
        repository.allConversationsFlow,
        selectedFilterLabel,
        searchQuery
    ) { conversations, filter, query ->
        conversations.filter { conv ->
            val matchesFilter = if (filter == ContactLabel.ALL) true else conv.label == filter
            val matchesQuery = if (query.isBlank()) true else {
                conv.recipientName.contains(query, ignoreCase = true) ||
                    conv.lastMessageSnippet.contains(query, ignoreCase = true) ||
                    conv.customerNotes.contains(query, ignoreCase = true)
            }
            matchesFilter && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active conversation
    val activeConversationId = MutableStateFlow<String?>(null)
    val activeConversation = MutableStateFlow<ConversationEntity?>(null)
    val activeMessages = MutableStateFlow<List<MessageEntity>>(emptyList())
    val activeMemory = MutableStateFlow<List<MemoryFactEntity>>(emptyList())
    val isAiThinking = MutableStateFlow(false)

    // SnackBar / Alert banner
    val snackbarMessage = MutableStateFlow<String?>(null)

    fun selectConversation(conversationId: String) {
        activeConversationId.value = conversationId
        viewModelScope.launch {
            repository.getConversationFlow(conversationId).collect {
                activeConversation.value = it
            }
        }
        viewModelScope.launch {
            repository.getMessagesFlow(conversationId).collect {
                activeMessages.value = it
            }
        }
        viewModelScope.launch {
            repository.getMemoryFlow(conversationId).collect {
                activeMemory.value = it
            }
        }
    }

    fun clearActiveConversation() {
        activeConversationId.value = null
        activeConversation.value = null
        activeMessages.value = emptyList()
        activeMemory.value = emptyList()
    }

    // Controls
    fun toggleBusyMode(enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleBusyMode(enabled)
            snackbarMessage.value = if (enabled) "Busy Mode Activated: AI will auto-reply to messages." else "Busy Mode Turned OFF"
        }
    }

    fun toggleWelcomeSystem(enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleWelcomeSystem(enabled)
            snackbarMessage.value = if (enabled) "Welcome System Activated" else "Welcome System Paused"
        }
    }

    fun toggleAiMemory(enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleAiMemory(enabled)
            snackbarMessage.value = if (enabled) "AI Conversation Memory Enabled" else "AI Memory Disabled"
        }
    }

    fun disconnectFacebook() {
        viewModelScope.launch {
            repository.disconnectFacebook()
            snackbarMessage.value = "Facebook Page Disconnected securely."
        }
    }

    fun reconnectFacebook(pageId: String, pageName: String) {
        viewModelScope.launch {
            repository.reconnectFacebook(pageId, pageName)
            snackbarMessage.value = "Meta Page Connected & Permissions Verified!"
        }
    }

    fun takeOverActiveConversation(reason: String = "Owner took over the conversation") {
        val id = activeConversationId.value ?: return
        viewModelScope.launch {
            repository.takeOverConversation(id, reason)
            snackbarMessage.value = "Human Takeover Active. AI responses paused for this chat."
        }
    }

    fun returnActiveConversationToAi() {
        val id = activeConversationId.value ?: return
        viewModelScope.launch {
            repository.returnConversationToAi(id)
            snackbarMessage.value = "Handed back to AI Assistant Aria."
        }
    }

    fun updateActiveConversationLabel(label: ContactLabel) {
        val id = activeConversationId.value ?: return
        viewModelScope.launch {
            repository.updateContactLabel(id, label)
            snackbarMessage.value = "Contact label changed to: ${label.displayName}"
        }
    }

    fun updateActiveCustomerNotes(notes: String) {
        val id = activeConversationId.value ?: return
        viewModelScope.launch {
            repository.updateCustomerNotes(id, notes)
            snackbarMessage.value = "Customer notes updated."
        }
    }

    fun sendOwnerMessage(text: String) {
        val id = activeConversationId.value ?: return
        if (text.isBlank()) return
        viewModelScope.launch {
            repository.sendOwnerMessage(id, text)
        }
    }

    fun simulateIncomingCustomerMessage(text: String, targetConversationId: String? = null) {
        val id = targetConversationId ?: activeConversationId.value ?: "conv_tanvir_1"
        if (text.isBlank()) return

        viewModelScope.launch {
            isAiThinking.value = true
            repository.simulateIncomingCustomerMessage(id, text)
            isAiThinking.value = false
        }
    }

    fun updatePersonalityConfig(config: PersonalityConfigEntity) {
        viewModelScope.launch {
            repository.updatePersonality(config)
            snackbarMessage.value = "AI Personality and Instructions saved successfully!"
        }
    }

    fun addMemoryFact(category: String, fact: String) {
        val id = activeConversationId.value ?: return
        if (fact.isBlank()) return
        viewModelScope.launch {
            repository.addMemoryFact(id, category, fact)
            snackbarMessage.value = "Context fact added to memory."
        }
    }

    fun deleteMemoryFact(factId: Long) {
        viewModelScope.launch {
            repository.deleteMemoryFact(factId)
            snackbarMessage.value = "Memory item deleted."
        }
    }

    fun clearActiveConversationMemory() {
        val id = activeConversationId.value ?: return
        viewModelScope.launch {
            repository.clearConversationMemory(id)
            snackbarMessage.value = "All memory facts cleared for this conversation."
        }
    }

    fun deleteActiveConversation() {
        val id = activeConversationId.value ?: return
        viewModelScope.launch {
            repository.deleteConversation(id)
            clearActiveConversation()
            snackbarMessage.value = "Conversation and related data permanently deleted."
        }
    }

    fun markNotificationsRead() {
        viewModelScope.launch {
            repository.markNotificationsRead()
        }
    }

    fun updateReviewStatus(id: Long, status: ReviewStatus) {
        viewModelScope.launch {
            repository.updateReviewStatus(id, status)
            snackbarMessage.value = "Contact review marked as: ${status.name}"
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAllData()
            clearActiveConversation()
            snackbarMessage.value = "All local data reset per GDPR / Meta Policy."
        }
    }

    fun clearSnackbar() {
        snackbarMessage.value = null
    }
}
