package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.MarkChatUnread
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ContactLabel
import com.example.data.models.ConversationEntity
import com.example.data.models.PageConnectionEntity
import com.example.data.models.PersonalityConfigEntity
import com.example.ui.components.ContactLabelBadge
import com.example.ui.components.StatusPill
import com.example.ui.components.UserAvatar
import com.example.ui.theme.AiPurple
import com.example.ui.theme.AiPurpleLight
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MetaBlue
import com.example.ui.theme.MetaDarkBlue
import com.example.ui.theme.MetaLightBlue
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber

@Composable
fun DashboardScreen(
    pageConnection: PageConnectionEntity?,
    personality: PersonalityConfigEntity?,
    conversations: List<ConversationEntity>,
    onToggleBusyMode: (Boolean) -> Unit,
    onToggleWelcomeSystem: (Boolean) -> Unit,
    onOpenConnectDialog: () -> Unit,
    onSelectConversation: (String) -> Unit,
    onSimulateMessage: (String) -> Unit
) {
    var simulatorInput by remember { mutableStateOf("") }

    val totalMessagesToday = 24
    val needsHumanCount = conversations.count { it.label == ContactLabel.NEEDS_HUMAN_REPLY || it.isHumanTakeover }
    val aiHandledCount = conversations.count { it.isAiActive && !it.isHumanTakeover }
    val humanHandledCount = conversations.count { it.isHumanTakeover }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // 1. Facebook Page Connection Banner (Requirement 1)
        PageConnectionCard(
            pageConnection = pageConnection,
            onOpenConnectDialog = onOpenConnectDialog
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 2. Control Switches (Requirement 4 & 5: Busy Mode & Welcome System)
        QuickControlsRow(
            isBusyMode = personality?.isBusyModeActive ?: true,
            isWelcome = personality?.isWelcomeSystemEnabled ?: true,
            onToggleBusy = onToggleBusyMode,
            onToggleWelcome = onToggleWelcomeSystem
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 3. Analytics & Overview Grid (Requirement 10: Dashboard)
        Text(
            text = "Conversation Overview",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                title = "Today's Messages",
                value = "$totalMessagesToday",
                icon = Icons.Default.QuestionAnswer,
                tint = MetaBlue,
                bg = MetaLightBlue,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                title = "Needs Human",
                value = "$needsHumanCount",
                icon = Icons.Default.Warning,
                tint = if (needsHumanCount > 0) ErrorRed else SuccessGreen,
                bg = if (needsHumanCount > 0) Color(0xFFFEE2E2) else Color(0xFFDCFCE7),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                title = "AI Handled",
                value = "$aiHandledCount",
                icon = Icons.Default.AutoAwesome,
                tint = AiPurple,
                bg = AiPurpleLight,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                title = "Owner Handled",
                value = "$humanHandledCount",
                icon = Icons.Default.Person,
                tint = Color(0xFF0284C7),
                bg = Color(0xFFE0F2FE),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 4. Live Message Simulator Sandbox (Tests Requirements 2, 3, 4, 9)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(AiPurpleLight)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ElectricBolt,
                            contentDescription = null,
                            tint = AiPurple,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Interactive AI Sandbox",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Test Bangla, Banglish, and English message handling",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Quick test pills
                val quickPills = listOf(
                    "bhai delivery charge koto? chittagong e hobe?",
                    "আপনাদের শোরুমের ঠিকানা কোথায়?",
                    "bhai ami owner er shathe kotha bolte chai",
                    "Do you have cash on delivery?",
                    "baje service amr taka ferot den"
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(quickPills) { pill ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.clickable { simulatorInput = pill }
                        ) {
                            Text(
                                text = pill,
                                fontSize = 11.sp,
                                maxLines = 1,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = simulatorInput,
                        onValueChange = { simulatorInput = it },
                        placeholder = { Text("Type customer message...", fontSize = 12.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (simulatorInput.isNotBlank()) {
                                onSimulateMessage(simulatorInput)
                                simulatorInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MetaBlue),
                        shape = RoundedCornerShape(12.dp),
                        enabled = simulatorInput.isNotBlank()
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = "Send", modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 5. Recent Conversations (Requirement 10 & 11)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "Recent Page Conversations",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "${conversations.size} active",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        conversations.take(4).forEach { conv ->
            RecentConversationCard(
                conversation = conv,
                onClick = { onSelectConversation(conv.conversationId) }
            )
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
private fun PageConnectionCard(
    pageConnection: PageConnectionEntity?,
    onOpenConnectDialog: () -> Unit
) {
    val isConnected = pageConnection?.isConnected == true

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (isConnected) MetaBlue else Color(0xFF64748B))
                    ) {
                        Icon(
                            imageVector = if (isConnected) Icons.Default.Link else Icons.Default.LinkOff,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = pageConnection?.pageName ?: "Dhaka Tech & Craft Store",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(if (isConnected) SuccessGreen else ErrorRed)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = if (isConnected) "Connected • Meta OAuth Active" else "Disconnected",
                                fontSize = 11.sp,
                                color = if (isConnected) SuccessGreen else ErrorRed,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                OutlinedButton(
                    onClick = onOpenConnectDialog,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = if (isConnected) "Manage" else "Connect",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Details line
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Page ID", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(pageConnection?.pageId ?: "109847291847120", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
                Column {
                    Text("OAuth Token", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(pageConnection?.tokenMasked ?: "EAAGm0P...Valid", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
                Column {
                    Text("Permissions", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("pages_messaging", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = MetaBlue)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Meta Graph API Rate Limit Meter
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Meta Graph API Rate Limit:",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = "${pageConnection?.rateLimitCallsUsed ?: 42} / ${pageConnection?.rateLimitMax ?: 200} calls/hr (OK)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SuccessGreen
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { (pageConnection?.rateLimitCallsUsed ?: 42) / 200f },
                color = MetaBlue,
                trackColor = MetaLightBlue,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp))
            )
        }
    }
}

@Composable
private fun QuickControlsRow(
    isBusyMode: Boolean,
    isWelcome: Boolean,
    onToggleBusy: (Boolean) -> Unit,
    onToggleWelcome: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Busy Mode Card
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isBusyMode) MetaLightBlue else MaterialTheme.colorScheme.surface
            ),
            modifier = Modifier.weight(1f)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Busy Mode",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (isBusyMode) MetaDarkBlue else MaterialTheme.colorScheme.onSurface
                    )
                    Switch(
                        checked = isBusyMode,
                        onCheckedChange = onToggleBusy,
                        colors = SwitchDefaults.colors(checkedThumbColor = MetaBlue, checkedTrackColor = Color.White)
                    )
                }
                Text(
                    text = if (isBusyMode) "AI handles Page chats automatically" else "Manual reply mode",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 13.sp
                )
            }
        }

        // Welcome System Card
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isWelcome) AiPurpleLight else MaterialTheme.colorScheme.surface
            ),
            modifier = Modifier.weight(1f)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Welcome Bot",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (isWelcome) AiPurple else MaterialTheme.colorScheme.onSurface
                    )
                    Switch(
                        checked = isWelcome,
                        onCheckedChange = onToggleWelcome,
                        colors = SwitchDefaults.colors(checkedThumbColor = AiPurple, checkedTrackColor = Color.White)
                    )
                }
                Text(
                    text = if (isWelcome) "Auto friendly greeting active" else "Welcome greetings paused",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 13.sp
                )
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    icon: ImageVector,
    tint: Color,
    bg: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(bg)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = tint,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = value,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = title,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun RecentConversationCard(
    conversation: ConversationEntity,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            UserAvatar(name = conversation.recipientName, size = 42)

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = conversation.recipientName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    StatusPill(
                        isHumanTakeover = conversation.isHumanTakeover,
                        isNeedsHuman = conversation.label == ContactLabel.NEEDS_HUMAN_REPLY
                    )
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = conversation.lastMessageSnippet,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ContactLabelBadge(label = conversation.label)
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = conversation.detectedLanguage,
                            fontSize = 9.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Icon(
                imageVector = Icons.Default.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
