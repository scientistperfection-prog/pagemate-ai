package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Label
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ContactLabel
import com.example.data.models.ConversationEntity
import com.example.data.models.MemoryFactEntity
import com.example.data.models.MessageEntity
import com.example.data.models.SenderType
import com.example.ui.components.ContactLabelBadge
import com.example.ui.components.UserAvatar
import com.example.ui.dialogs.MemorySheetDialog
import com.example.ui.theme.AiPurple
import com.example.ui.theme.AiPurpleLight
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MetaBlue
import com.example.ui.theme.MetaDarkBlue
import com.example.ui.theme.MetaLightBlue
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    conversation: ConversationEntity,
    messages: List<MessageEntity>,
    memoryFacts: List<MemoryFactEntity>,
    isAiThinking: Boolean,
    isAiMemoryGloballyEnabled: Boolean,
    onBack: () -> Unit,
    onTakeOver: () -> Unit,
    onReturnToAi: () -> Unit,
    onUpdateLabel: (ContactLabel) -> Unit,
    onSendOwnerMessage: (String) -> Unit,
    onSimulateCustomerMessage: (String) -> Unit,
    onAddMemoryFact: (String, String) -> Unit,
    onDeleteMemoryFact: (Long) -> Unit,
    onClearConversationMemory: () -> Unit,
    onDeleteConversation: () -> Unit,
    onToggleGlobalMemory: (Boolean) -> Unit
) {
    var ownerMessageText by remember { mutableStateOf("") }
    var showMenu by remember { mutableStateOf(false) }
    var showMemorySheet by remember { mutableStateOf(false) }
    var showBlockDialog by remember { mutableStateOf(false) }
    var showSimulatorDialog by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        // Messenger-style Top Bar
        TopAppBar(
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    UserAvatar(name = conversation.recipientName, size = 38)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = conversation.recipientName,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (conversation.isHumanTakeover) "Owner Takeover Active" else "AI Aria Active",
                                fontSize = 11.sp,
                                color = if (conversation.isHumanTakeover) AiPurple else MetaBlue,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "• Messenger",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            },
            actions = {
                // Human Takeover / Return to AI button
                if (conversation.isHumanTakeover) {
                    Button(
                        onClick = onReturnToAi,
                        colors = ButtonDefaults.buttonColors(containerColor = MetaBlue),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Hand to AI", fontSize = 11.sp)
                    }
                } else {
                    OutlinedButton(
                        onClick = onTakeOver,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Person, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Take Over", fontSize = 11.sp)
                    }
                }

                IconButton(onClick = { showMemorySheet = true }) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = "Conversation Memory",
                        tint = if (memoryFacts.isNotEmpty()) AiPurple else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(onClick = { showMenu = true }) {
                    Icon(imageVector = Icons.Default.MoreVert, contentDescription = "Options")
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Label: Customer") },
                        onClick = {
                            onUpdateLabel(ContactLabel.CUSTOMER)
                            showMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Label: Important") },
                        onClick = {
                            onUpdateLabel(ContactLabel.IMPORTANT)
                            showMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Label: Needs Human Reply") },
                        onClick = {
                            onUpdateLabel(ContactLabel.NEEDS_HUMAN_REPLY)
                            showMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Label: Friend") },
                        onClick = {
                            onUpdateLabel(ContactLabel.FRIEND)
                            showMenu = false
                        }
                    )
                    HorizontalDivider()
                    DropdownMenuItem(
                        text = { Text("Simulate Incoming Message") },
                        onClick = {
                            showSimulatorDialog = true
                            showMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Block / Ignore (Meta API)", color = ErrorRed) },
                        onClick = {
                            showBlockDialog = true
                            showMenu = false
                        }
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )

        // Handoff & Takeover Notification Banner (Requirements 4 & 9)
        if (conversation.label == ContactLabel.NEEDS_HUMAN_REPLY || conversation.isHumanTakeover) {
            Surface(
                color = if (conversation.label == ContactLabel.NEEDS_HUMAN_REPLY) Color(0xFFFEF2F2) else AiPurpleLight,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (conversation.label == ContactLabel.NEEDS_HUMAN_REPLY) Icons.Default.Warning else Icons.Default.Person,
                        contentDescription = null,
                        tint = if (conversation.label == ContactLabel.NEEDS_HUMAN_REPLY) ErrorRed else AiPurple,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (conversation.label == ContactLabel.NEEDS_HUMAN_REPLY) {
                            "Human assistance requested! Reason: ${conversation.handoffReason.ifBlank { "Complex query/low AI confidence." }}"
                        } else {
                            "Human Takeover Active. AI auto-reply is paused. You are chatting as the page owner."
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (conversation.label == ContactLabel.NEEDS_HUMAN_REPLY) Color(0xFF991B1B) else Color(0xFF5B21B6),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Contact label and voluntary note chip strip
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            ContactLabelBadge(label = conversation.label)
            Spacer(modifier = Modifier.width(8.dp))
            if (memoryFacts.isNotEmpty()) {
                Surface(
                    color = AiPurpleLight,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.clickable { showMemorySheet = true }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Psychology, contentDescription = null, tint = AiPurple, modifier = Modifier.size(11.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("${memoryFacts.size} memory facts", fontSize = 10.sp, color = AiPurple, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Messages List
        LazyColumn(
            state = listState,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp, vertical = 4.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                MessageBubbleItem(message = msg)
            }

            if (isAiThinking) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        CircularProgressIndicator(
                            strokeWidth = 2.dp,
                            color = MetaBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("AI Aria is formulating response...", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        // Quick Reply Suggestions Row
        val quickOwnerReplies = listOf(
            "ধন্যবাদ আমাদের সাথে থাকার জন্য!",
            "ঢাকা সিটিতে ডেলিভারি চার্জ ৬০ টাকা, ঢাকার বাইরে ১২০ টাকা।",
            "ক্যাশ অন ডেলিভারি সুবিধা আছে।",
            "অর্ডারের জন্য নাম, ঠিকানা ও ফোন নাম্বার দিন।"
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
        ) {
            items(quickOwnerReplies) { reply ->
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.clickable { ownerMessageText = reply }
                ) {
                    Text(
                        text = reply,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        }

        // Owner Input Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 3.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { showSimulatorDialog = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ElectricBolt,
                        contentDescription = "Simulate Customer Question",
                        tint = AiPurple
                    )
                }

                OutlinedTextField(
                    value = ownerMessageText,
                    onValueChange = { ownerMessageText = it },
                    placeholder = {
                        Text(
                            text = if (conversation.isHumanTakeover) "Reply as Page Owner..." else "Send message as Owner...",
                            fontSize = 13.sp
                        )
                    },
                    shape = RoundedCornerShape(20.dp),
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 6.dp)
                )

                IconButton(
                    onClick = {
                        if (ownerMessageText.isNotBlank()) {
                            onSendOwnerMessage(ownerMessageText)
                            ownerMessageText = ""
                        }
                    },
                    enabled = ownerMessageText.isNotBlank(),
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(if (ownerMessageText.isNotBlank()) MetaBlue else MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send",
                        tint = if (ownerMessageText.isNotBlank()) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }

    // Memory Sheet Dialog
    if (showMemorySheet) {
        MemorySheetDialog(
            conversation = conversation,
            memoryFacts = memoryFacts,
            isAiMemoryGloballyEnabled = isAiMemoryGloballyEnabled,
            onDismiss = { showMemorySheet = false },
            onAddFact = onAddMemoryFact,
            onDeleteFact = onDeleteMemoryFact,
            onClearAllMemory = onClearConversationMemory,
            onDeleteEntireConversation = onDeleteConversation,
            onToggleGlobalMemory = onToggleGlobalMemory
        )
    }

    // Meta Block / Ignore Confirmation
    if (showBlockDialog) {
        AlertDialog(
            onDismissRequest = { showBlockDialog = false },
            icon = { Icon(Icons.Default.Block, contentDescription = null, tint = ErrorRed) },
            title = { Text("Block Customer on Facebook?") },
            text = {
                Text(
                    "Calls Meta Graph API endpoint `POST /{page-id}/blocked` to block messages from this Facebook user. This follows official Meta Platform guidelines.",
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { showBlockDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("Confirm Block")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBlockDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Simulator Question Inserter Dialog
    if (showSimulatorDialog) {
        var testQuestion by remember { mutableStateOf("") }
        val testPresets = listOf(
            "bhai delivery charge koto? chittagong e delivery hobe?",
            "আপনাদের শোরুমের ঠিকানা কোথায়?",
            "bhai ami owner er shathe kotha bolte chai",
            "Do you have cash on delivery and return warranty?",
            "baje service amr taka ferot den"
        )

        AlertDialog(
            onDismissRequest = { showSimulatorDialog = false },
            title = { Text("Simulate Incoming Customer Message", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Select a realistic customer question or type one:", fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    testPresets.forEach { preset ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clickable { testQuestion = preset }
                        ) {
                            Text(
                                text = preset,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = testQuestion,
                        onValueChange = { testQuestion = it },
                        placeholder = { Text("Custom message in Bangla / Banglish / English...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (testQuestion.isNotBlank()) {
                            onSimulateCustomerMessage(testQuestion)
                            showSimulatorDialog = false
                        }
                    },
                    enabled = testQuestion.isNotBlank()
                ) {
                    Text("Simulate Message")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSimulatorDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun MessageBubbleItem(message: MessageEntity) {
    val isUser = message.senderType == SenderType.USER
    val isAi = message.senderType == SenderType.AI_ASSISTANT
    val isOwner = message.senderType == SenderType.HUMAN_OWNER

    val timeStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(message.timestamp))

    Column(
        horizontalAlignment = if (isUser) Alignment.Start else Alignment.End,
        modifier = Modifier.fillMaxWidth()
    ) {
        // Tag banner above bubble
        if (!isUser) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 2.dp, end = 4.dp)
            ) {
                if (isAi) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = MetaBlue,
                        modifier = Modifier.size(11.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = if (message.isWelcomeMessage) "AI Assistant • Welcome Trigger" else "AI Assistant (Aria)",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetaBlue
                    )
                } else if (isOwner) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = AiPurple,
                        modifier = Modifier.size(11.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "Page Owner (Human)",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = AiPurple
                    )
                }
            }
        }

        // Bubble shape & background
        val bubbleColor = when {
            isUser -> Color.White
            isAi -> MetaBlue
            else -> MetaDarkBlue
        }
        val textColor = if (isUser) Color(0xFF0F172A) else Color.White

        Surface(
            color = bubbleColor,
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 2.dp else 16.dp,
                bottomEnd = if (isUser) 16.dp else 2.dp
            ),
            shadowElevation = if (isUser) 1.dp else 0.dp,
            modifier = Modifier.widthIn(max = 290.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text(
                    text = message.text,
                    color = textColor,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Time and status
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text(
                        text = timeStr,
                        fontSize = 9.sp,
                        color = if (isUser) Color(0xFF94A3B8) else Color(0xFFE2E8F0)
                    )
                    if (!isUser) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.DoneAll,
                            contentDescription = "Delivered",
                            tint = Color(0xFFE2E8F0),
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }
        }

        // Confidence and intent chips for AI messages (Requirements 2, 8, 9)
        if (isAi && !message.isWelcomeMessage) {
            Spacer(modifier = Modifier.height(2.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.End,
                modifier = Modifier.padding(end = 4.dp)
            ) {
                Surface(
                    color = if (message.isHumanHandoffTrigger) Color(0xFFFEE2E2) else Color(0xFFEFF6FF),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "${(message.aiConfidence * 100).toInt()}% Confident • ${message.detectedIntent}",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (message.isHumanHandoffTrigger) ErrorRed else MetaBlue,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                    )
                }
            }
        }
    }
}
