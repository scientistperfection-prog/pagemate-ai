package com.example.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ContactLabel(val displayName: String) {
    ALL("All"),
    NEEDS_HUMAN_REPLY("Needs Human Reply"),
    CUSTOMER("Customer"),
    FRIEND("Friend"),
    NEW_CONTACT("New Contact"),
    IMPORTANT("Important"),
    FOLLOW_UP("Follow-up")
}

enum class SenderType {
    USER,
    AI_ASSISTANT,
    HUMAN_OWNER
}

enum class MessageDeliveryStatus {
    SENT,
    DELIVERED,
    READ
}

enum class LanguageMode(val displayName: String) {
    AUTO("Auto-Detect"),
    BANGLA("Bangla (বাংলা)"),
    BANGLISH("Banglish (বাংলিশ)"),
    ENGLISH("English")
}

enum class ToneStyle(val displayName: String) {
    FORMAL("Formal (ভদ্র ও মার্জিত)"),
    FRIENDLY("Friendly (বন্ধুত্বপূর্ণ ও আন্তরিক)"),
    CASUAL("Casual (সহজ ও সাবলীল)")
}

enum class ReplyLength(val displayName: String) {
    SHORT("Short (সংক্ষিপ্ত)"),
    NORMAL("Normal (পরিমিত)"),
    DETAILED("Detailed (বিস্তারিত)")
}

enum class EmojiLevel(val displayName: String) {
    NONE("None (কোনো ইমোজি নয়)"),
    MODERATE("Moderate (পরিমিত 😊)"),
    EXPRESSIVE("Expressive (প্রাণবন্ত 🎉✨)")
}

enum class NotificationType {
    HANDOFF_REQUESTED,
    LOW_CONFIDENCE,
    IMPORTANT_MESSAGE,
    BUSY_AUTO_REPLY
}

enum class ReviewStatus {
    PENDING,
    APPROVED,
    IGNORED
}

@Entity(tableName = "page_connection")
data class PageConnectionEntity(
    @PrimaryKey val id: Int = 1,
    val pageId: String = "109847291847120",
    val pageName: String = "Dhaka Tech & Craft Store",
    val category: String = "Retail & E-commerce Page",
    val isConnected: Boolean = true,
    val permissions: String = "pages_messaging,pages_manage_metadata,pages_read_engagement,pages_show_list",
    val tokenMasked: String = "EAAGm0PXq...k984Zb",
    val connectedSince: String = "September 2026",
    val rateLimitCallsUsed: Int = 42,
    val rateLimitMax: Int = 200,
    val cpuTimePercent: Int = 18
)

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val conversationId: String,
    val recipientId: String,
    val recipientName: String,
    val recipientAvatarUrl: String = "",
    val label: ContactLabel = ContactLabel.NEW_CONTACT,
    val isAiActive: Boolean = true,
    val isHumanTakeover: Boolean = false,
    val handoffReason: String = "",
    val unreadCount: Int = 0,
    val lastMessageSnippet: String = "",
    val lastMessageTimestamp: Long = System.currentTimeMillis(),
    val detectedLanguage: String = "Banglish",
    val customerNotes: String = ""
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: String,
    val text: String,
    val senderType: SenderType,
    val timestamp: Long = System.currentTimeMillis(),
    val status: MessageDeliveryStatus = MessageDeliveryStatus.READ,
    val aiConfidence: Float = 0.95f,
    val detectedIntent: String = "General Inquiry",
    val isWelcomeMessage: Boolean = false,
    val isHumanHandoffTrigger: Boolean = false
)

@Entity(tableName = "memory_facts")
data class MemoryFactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: String,
    val category: String, // "Preference", "Support Issue", "Pending Request", "Delivery Address"
    val factText: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isEnabled: Boolean = true
)

@Entity(tableName = "personality_config")
data class PersonalityConfigEntity(
    @PrimaryKey val id: Int = 1,
    val assistantName: String = "Aria - AI Page Assistant",
    val primaryLanguage: LanguageMode = LanguageMode.AUTO,
    val toneStyle: ToneStyle = ToneStyle.FRIENDLY,
    val replyLength: ReplyLength = ReplyLength.SHORT,
    val emojiLevel: EmojiLevel = EmojiLevel.MODERATE,
    val systemInstructions: String = "You are my official Facebook Page AI assistant. Reply naturally in Bangla, Banglish, or English matching the user's language. Keep replies warm, helpful, and concise. Never claim to be the human owner. Do not make unauthorized discounts or promises. If a user asks for a human, expresses anger, or asks something uncertain, politely request human assistance.",
    val frequentlyUsedPhrases: String = "মেসেজ করার জন্য ধন্যবাদ!||আমাদের ঢাকা সিটিতে ডেলিভারি চার্জ ৬০ টাকা, ঢাকার বাইরে ১২০ টাকা।||ক্যাশ অন ডেলিভারি সুবিধা আছে।||ধন্যবাদ আমাদের সাথে থাকার জন্য!",
    val topicsAllowed: String = "Product inquiries, Pricing & Delivery rates, Order placement, Business hours, Return policy",
    val topicsAvoided: String = "Discounts above 10%, Personal opinions, Political topics, Direct payment details without verification",
    val fewShotExamples: String = "User: delivery charge koto? -> Assistant: হ্যালো! ঢাকা সিটির মধ্যে ডেলিভারি ৬০ টাকা এবং ঢাকার বাইরে ১২০ টাকা। ক্যাশ অন ডেলিভারি এভেইলেবল। 😊\nUser: bhai owner ke chai -> Assistant: বুঝতে পেরেছি। আমি পেইজের ওনারকে জানাচ্ছি, কিছুক্ষণের মধ্যে উনি আপনার সাথে কথা বলবেন। ধন্যবাদ!",
    val isBusyModeActive: Boolean = true,
    val isWelcomeSystemEnabled: Boolean = true,
    val welcomeFirstMessage: String = "হ্যালো! 👋 মেসেজ করার জন্য ধন্যবাদ। আমি পেইজ অ্যাসিস্ট্যান্ট Aria। আমি এখন আপনাকে সাহায্য করার চেষ্টা করছি। 😊",
    val welcomeFollowUpMessage: String = "আপনার যে কোনো প্রশ্ন, প্রোডাক্টের তথ্য বা অর্ডারের বিবরণ লিখে জানাতে পারেন।",
    val welcomeDelaySeconds: Int = 2,
    val isAiMemoryEnabled: Boolean = true
)

@Entity(tableName = "app_notifications")
data class AppNotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String,
    val type: NotificationType,
    val conversationId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

@Entity(tableName = "friend_reviews")
data class FriendReviewEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val contactName: String,
    val messengerProfileId: String,
    val mutualContext: String,
    val requestedAt: Long = System.currentTimeMillis(),
    val status: ReviewStatus = ReviewStatus.PENDING,
    val notes: String = "Connected via Facebook Page inquiry"
)
