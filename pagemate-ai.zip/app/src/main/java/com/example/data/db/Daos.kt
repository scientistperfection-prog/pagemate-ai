package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.models.AppNotificationEntity
import com.example.data.models.ContactLabel
import com.example.data.models.ConversationEntity
import com.example.data.models.FriendReviewEntity
import com.example.data.models.MemoryFactEntity
import com.example.data.models.MessageEntity
import com.example.data.models.PageConnectionEntity
import com.example.data.models.PersonalityConfigEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PageDao {
    @Query("SELECT * FROM page_connection WHERE id = 1 LIMIT 1")
    fun getPageConnection(): Flow<PageConnectionEntity?>

    @Query("SELECT * FROM page_connection WHERE id = 1 LIMIT 1")
    suspend fun getPageConnectionDirect(): PageConnectionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(page: PageConnectionEntity)
}

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY lastMessageTimestamp DESC")
    fun getAllConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE label = :label ORDER BY lastMessageTimestamp DESC")
    fun getConversationsByLabel(label: ContactLabel): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE conversationId = :id LIMIT 1")
    fun getConversationFlow(id: String): Flow<ConversationEntity?>

    @Query("SELECT * FROM conversations WHERE conversationId = :id LIMIT 1")
    suspend fun getConversation(id: String): ConversationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(conversation: ConversationEntity)

    @Update
    suspend fun update(conversation: ConversationEntity)

    @Query("UPDATE conversations SET isHumanTakeover = :takeover, handoffReason = :reason WHERE conversationId = :id")
    suspend fun updateTakeover(id: String, takeover: Boolean, reason: String)

    @Query("UPDATE conversations SET label = :label WHERE conversationId = :id")
    suspend fun updateLabel(id: String, label: ContactLabel)

    @Query("UPDATE conversations SET customerNotes = :notes WHERE conversationId = :id")
    suspend fun updateCustomerNotes(id: String, notes: String)

    @Query("DELETE FROM conversations WHERE conversationId = :id")
    suspend fun deleteConversation(id: String)

    @Query("DELETE FROM conversations")
    suspend fun clearAll()
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun getMessagesForConversation(conversationId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    suspend fun getMessagesDirect(conversationId: String): List<MessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity): Long

    @Query("DELETE FROM messages WHERE conversationId = :conversationId")
    suspend fun deleteMessagesForConversation(conversationId: String)

    @Query("DELETE FROM messages")
    suspend fun clearAll()
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memory_facts WHERE conversationId = :conversationId ORDER BY timestamp DESC")
    fun getMemoryForConversation(conversationId: String): Flow<List<MemoryFactEntity>>

    @Query("SELECT * FROM memory_facts WHERE conversationId = :conversationId AND isEnabled = 1 ORDER BY timestamp DESC")
    suspend fun getActiveMemoryDirect(conversationId: String): List<MemoryFactEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(fact: MemoryFactEntity): Long

    @Update
    suspend fun updateMemory(fact: MemoryFactEntity)

    @Query("DELETE FROM memory_facts WHERE id = :id")
    suspend fun deleteMemoryById(id: Long)

    @Query("DELETE FROM memory_facts WHERE conversationId = :conversationId")
    suspend fun deleteMemoryForConversation(conversationId: String)

    @Query("DELETE FROM memory_facts")
    suspend fun clearAll()
}

@Dao
interface PersonalityDao {
    @Query("SELECT * FROM personality_config WHERE id = 1 LIMIT 1")
    fun getPersonalityFlow(): Flow<PersonalityConfigEntity?>

    @Query("SELECT * FROM personality_config WHERE id = 1 LIMIT 1")
    suspend fun getPersonalityDirect(): PersonalityConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(config: PersonalityConfigEntity)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM app_notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<AppNotificationEntity>>

    @Query("SELECT COUNT(*) FROM app_notifications WHERE isRead = 0")
    fun getUnreadCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: AppNotificationEntity): Long

    @Query("UPDATE app_notifications SET isRead = 1")
    suspend fun markAllAsRead()

    @Query("DELETE FROM app_notifications WHERE id = :id")
    suspend fun deleteNotification(id: Long)

    @Query("DELETE FROM app_notifications")
    suspend fun clearAll()
}

@Dao
interface FriendReviewDao {
    @Query("SELECT * FROM friend_reviews ORDER BY requestedAt DESC")
    fun getAllReviews(): Flow<List<FriendReviewEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReview(review: FriendReviewEntity): Long

    @Query("UPDATE friend_reviews SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: Long, status: com.example.data.models.ReviewStatus)
}
