package com.example.data.repository

import android.content.Context
import com.example.ai.AssistantEngine
import com.example.data.db.AppDatabase
import com.example.data.models.AppNotificationEntity
import com.example.data.models.ContactLabel
import com.example.data.models.ConversationEntity
import com.example.data.models.FriendReviewEntity
import com.example.data.models.MemoryFactEntity
import com.example.data.models.MessageDeliveryStatus
import com.example.data.models.MessageEntity
import com.example.data.models.NotificationType
import com.example.data.models.PageConnectionEntity
import com.example.data.models.PersonalityConfigEntity
import com.example.data.models.ReviewStatus
import com.example.data.models.SenderType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppRepository private constructor(context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val pageDao = db.pageDao()
    private val convDao = db.conversationDao()
    private val msgDao = db.messageDao()
    private val memDao = db.memoryDao()
    private val personDao = db.personalityDao()
    private val notifDao = db.notificationDao()
    private val reviewDao = db.friendReviewDao()

    init {
        CoroutineScope(Dispatchers.IO).launch {
            seedDefaultDataIfNeeded()
        }
    }

    // Flows
    val pageConnectionFlow: Flow<PageConnectionEntity?> = pageDao.getPageConnection()
    val allConversationsFlow: Flow<List<ConversationEntity>> = convDao.getAllConversations()
    val personalityFlow: Flow<PersonalityConfigEntity?> = personDao.getPersonalityFlow()
    val notificationsFlow: Flow<List<AppNotificationEntity>> = notifDao.getAllNotifications()
    val unreadNotifsCountFlow: Flow<Int> = notifDao.getUnreadCount()
    val friendReviewsFlow: Flow<List<FriendReviewEntity>> = reviewDao.getAllReviews()

    fun getConversationFlow(id: String): Flow<ConversationEntity?> = convDao.getConversationFlow(id)
    fun getMessagesFlow(conversationId: String): Flow<List<MessageEntity>> = msgDao.getMessagesForConversation(conversationId)
    fun getMemoryFlow(conversationId: String): Flow<List<MemoryFactEntity>> = memDao.getMemoryForConversation(conversationId)

    // Page actions
    suspend fun disconnectFacebook() = withContext(Dispatchers.IO) {
        val current = pageDao.getPageConnectionDirect() ?: PageConnectionEntity()
        pageDao.insertOrUpdate(current.copy(isConnected = false, tokenMasked = "Disconnected"))
    }

    suspend fun reconnectFacebook(pageId: String, pageName: String) = withContext(Dispatchers.IO) {
        val current = pageDao.getPageConnectionDirect() ?: PageConnectionEntity()
        pageDao.insertOrUpdate(
            current.copy(
                pageId = pageId.ifBlank { "109847291847120" },
                pageName = pageName.ifBlank { "Dhaka Tech & Craft Store" },
                isConnected = true,
                tokenMasked = "EAAGm0PXq...92Fk1",
                connectedSince = "Connected Now (Active)",
                rateLimitCallsUsed = 12
            )
        )
    }

    suspend fun updatePersonality(config: PersonalityConfigEntity) = withContext(Dispatchers.IO) {
        personDao.insertOrUpdate(config)
    }

    suspend fun toggleBusyMode(active: Boolean) = withContext(Dispatchers.IO) {
        val current = personDao.getPersonalityDirect() ?: PersonalityConfigEntity()
        personDao.insertOrUpdate(current.copy(isBusyModeActive = active))
    }

    suspend fun toggleWelcomeSystem(active: Boolean) = withContext(Dispatchers.IO) {
        val current = personDao.getPersonalityDirect() ?: PersonalityConfigEntity()
        personDao.insertOrUpdate(current.copy(isWelcomeSystemEnabled = active))
    }

    suspend fun toggleAiMemory(active: Boolean) = withContext(Dispatchers.IO) {
        val current = personDao.getPersonalityDirect() ?: PersonalityConfigEntity()
        personDao.insertOrUpdate(current.copy(isAiMemoryEnabled = active))
    }

    // Conversation Actions
    suspend fun takeOverConversation(conversationId: String, reason: String = "Owner took manual control") = withContext(Dispatchers.IO) {
        convDao.updateTakeover(conversationId, takeover = true, reason = reason)
    }

    suspend fun returnConversationToAi(conversationId: String) = withContext(Dispatchers.IO) {
        convDao.updateTakeover(conversationId, takeover = false, reason = "")
        val conv = convDao.getConversation(conversationId)
        if (conv != null && conv.label == ContactLabel.NEEDS_HUMAN_REPLY) {
            convDao.updateLabel(conversationId, ContactLabel.CUSTOMER)
        }
    }

    suspend fun updateContactLabel(conversationId: String, label: ContactLabel) = withContext(Dispatchers.IO) {
        convDao.updateLabel(conversationId, label)
    }

    suspend fun updateCustomerNotes(conversationId: String, notes: String) = withContext(Dispatchers.IO) {
        convDao.updateCustomerNotes(conversationId, notes)
    }

    suspend fun markNotificationsRead() = withContext(Dispatchers.IO) {
        notifDao.markAllAsRead()
    }

    suspend fun updateReviewStatus(id: Long, status: ReviewStatus) = withContext(Dispatchers.IO) {
        reviewDao.updateStatus(id, status)
    }

    // Messaging Engine
    suspend fun sendOwnerMessage(conversationId: String, text: String) = withContext(Dispatchers.IO) {
        if (text.isBlank()) return@withContext
        val msg = MessageEntity(
            conversationId = conversationId,
            text = text.trim(),
            senderType = SenderType.HUMAN_OWNER,
            timestamp = System.currentTimeMillis(),
            status = MessageDeliveryStatus.DELIVERED
        )
        msgDao.insertMessage(msg)

        val conv = convDao.getConversation(conversationId)
        if (conv != null) {
            convDao.insertOrUpdate(
                conv.copy(
                    lastMessageSnippet = "Owner: ${text.trim()}",
                    lastMessageTimestamp = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun simulateIncomingCustomerMessage(
        conversationId: String,
        userText: String
    ): MessageEntity = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val userMsg = MessageEntity(
            conversationId = conversationId,
            text = userText.trim(),
            senderType = SenderType.USER,
            timestamp = now,
            status = MessageDeliveryStatus.READ
        )
        msgDao.insertMessage(userMsg)

        val conv = convDao.getConversation(conversationId) ?: ConversationEntity(
            conversationId = conversationId,
            recipientId = "usr_${System.currentTimeMillis() % 10000}",
            recipientName = "Customer",
            lastMessageSnippet = userText.trim(),
            lastMessageTimestamp = now
        )
        val config = personDao.getPersonalityDirect() ?: PersonalityConfigEntity()

        // Check if welcome message needed for fresh chat
        val existingMsgs = msgDao.getMessagesDirect(conversationId)
        val isFirstInteraction = existingMsgs.count { it.senderType == SenderType.USER } <= 1

        if (isFirstInteraction && config.isWelcomeSystemEnabled && !conv.isHumanTakeover) {
            val welcomeMsg = MessageEntity(
                conversationId = conversationId,
                text = config.welcomeFirstMessage,
                senderType = SenderType.AI_ASSISTANT,
                timestamp = now + 500,
                status = MessageDeliveryStatus.DELIVERED,
                aiConfidence = 1.0f,
                detectedIntent = "Welcome Trigger",
                isWelcomeMessage = true
            )
            msgDao.insertMessage(welcomeMsg)
        }

        // Process message through AI assistant engine
        val aiResult = AssistantEngine.processMessage(
            userMessage = userText,
            config = config
        )

        // If human handoff required
        if (aiResult.requiresHumanHandoff) {
            convDao.updateTakeover(conversationId, takeover = true, reason = aiResult.handoffReason)
            convDao.updateLabel(conversationId, ContactLabel.NEEDS_HUMAN_REPLY)

            notifDao.insertNotification(
                AppNotificationEntity(
                    title = "Human Assistance Requested",
                    description = "${conv.recipientName}: ${aiResult.handoffReason}",
                    type = NotificationType.HANDOFF_REQUESTED,
                    conversationId = conversationId,
                    timestamp = System.currentTimeMillis()
                )
            )
        }

        // If busy mode active or AI active and not manually taken over
        val aiReplyMsg = MessageEntity(
            conversationId = conversationId,
            text = aiResult.replyText,
            senderType = SenderType.AI_ASSISTANT,
            timestamp = now + 1200,
            status = MessageDeliveryStatus.DELIVERED,
            aiConfidence = aiResult.confidence,
            detectedIntent = aiResult.detectedIntent,
            isHumanHandoffTrigger = aiResult.requiresHumanHandoff
        )
        msgDao.insertMessage(aiReplyMsg)

        // Save memory facts if AI memory is enabled
        if (config.isAiMemoryEnabled && aiResult.extractedFacts.isNotEmpty()) {
            for ((category, fact) in aiResult.extractedFacts) {
                memDao.insertMemory(
                    MemoryFactEntity(
                        conversationId = conversationId,
                        category = category,
                        factText = fact,
                        timestamp = System.currentTimeMillis()
                    )
                )
            }
        }

        // Update conversation summary
        val updatedConv = conv.copy(
            lastMessageSnippet = "AI: ${aiResult.replyText.take(45)}...",
            lastMessageTimestamp = now + 1200,
            detectedLanguage = aiResult.detectedLanguage,
            label = if (aiResult.requiresHumanHandoff) ContactLabel.NEEDS_HUMAN_REPLY else conv.label
        )
        convDao.insertOrUpdate(updatedConv)

        return@withContext aiReplyMsg
    }

    // Memory Controls
    suspend fun addMemoryFact(conversationId: String, category: String, fact: String) = withContext(Dispatchers.IO) {
        memDao.insertMemory(
            MemoryFactEntity(
                conversationId = conversationId,
                category = category,
                factText = fact
            )
        )
    }

    suspend fun deleteMemoryFact(id: Long) = withContext(Dispatchers.IO) {
        memDao.deleteMemoryById(id)
    }

    suspend fun clearConversationMemory(conversationId: String) = withContext(Dispatchers.IO) {
        memDao.deleteMemoryForConversation(conversationId)
    }

    suspend fun deleteConversation(conversationId: String) = withContext(Dispatchers.IO) {
        msgDao.deleteMessagesForConversation(conversationId)
        memDao.deleteMemoryForConversation(conversationId)
        convDao.deleteConversation(conversationId)
    }

    suspend fun clearAllData() = withContext(Dispatchers.IO) {
        msgDao.clearAll()
        memDao.clearAll()
        convDao.clearAll()
        notifDao.clearAll()
    }

    private suspend fun seedDefaultDataIfNeeded() {
        val existingPage = pageDao.getPageConnectionDirect()
        if (existingPage == null) {
            pageDao.insertOrUpdate(PageConnectionEntity())
        }

        val existingPerson = personDao.getPersonalityDirect()
        if (existingPerson == null) {
            personDao.insertOrUpdate(PersonalityConfigEntity())
        }

        val existingConvs = convDao.getAllConversations().firstOrNull() ?: emptyList()
        if (existingConvs.isEmpty()) {
            val now = System.currentTimeMillis()

            // 1. Tanvir Ahmed (Banglish FAQ customer)
            val c1 = ConversationEntity(
                conversationId = "conv_tanvir_1",
                recipientId = "fb_tanvir_981",
                recipientName = "Tanvir Ahmed",
                recipientAvatarUrl = "",
                label = ContactLabel.CUSTOMER,
                isAiActive = true,
                isHumanTakeover = false,
                lastMessageSnippet = "AI: Amader Dhaka city te delivery charge 60...",
                lastMessageTimestamp = now - 1000 * 60 * 15,
                detectedLanguage = "Banglish",
                customerNotes = "Regular customer. Interested in wireless mechanical keyboards."
            )
            convDao.insertOrUpdate(c1)

            msgDao.insertMessage(
                MessageEntity(
                    conversationId = "conv_tanvir_1",
                    text = "bhai delivery charge koto? chittagong e delivery hobe?",
                    senderType = SenderType.USER,
                    timestamp = now - 1000 * 60 * 18,
                    aiConfidence = 0.96f
                )
            )
            msgDao.insertMessage(
                MessageEntity(
                    conversationId = "conv_tanvir_1",
                    text = "Amader Dhaka city te delivery charge 60 taka and Dhakar baire 120 taka. Cash on delivery available everywhere in BD! Dhakay 24-48 hours and baire 2-3 diner moddhe delivery hoye thake. 😊",
                    senderType = SenderType.AI_ASSISTANT,
                    timestamp = now - 1000 * 60 * 15,
                    aiConfidence = 0.96f,
                    detectedIntent = "Pricing & Delivery"
                )
            )
            memDao.insertMemory(
                MemoryFactEntity(
                    conversationId = "conv_tanvir_1",
                    category = "Preference",
                    factText = "Customer Location: Chittagong"
                )
            )
            memDao.insertMemory(
                MemoryFactEntity(
                    conversationId = "conv_tanvir_1",
                    category = "Preference",
                    factText = "Prefers Cash on Delivery (COD)"
                )
            )

            // 2. Farhan Kabir (Needs Human Reply / Discrepancy)
            val c2 = ConversationEntity(
                conversationId = "conv_farhan_2",
                recipientId = "fb_farhan_442",
                recipientName = "Farhan Kabir",
                recipientAvatarUrl = "",
                label = ContactLabel.NEEDS_HUMAN_REPLY,
                isAiActive = false,
                isHumanTakeover = true,
                handoffReason = "Customer explicitly requested human assistance regarding parcel discrepancy.",
                lastMessageSnippet = "Customer: bhai ami owner er shathe kotha bolte chai...",
                lastMessageTimestamp = now - 1000 * 60 * 45,
                detectedLanguage = "Banglish",
                customerNotes = "Order #DH-9102 pending review."
            )
            convDao.insertOrUpdate(c2)

            msgDao.insertMessage(
                MessageEntity(
                    conversationId = "conv_farhan_2",
                    text = "bhai ami owner er shathe kotha bolte chai, amr parcel e ekta item missing",
                    senderType = SenderType.USER,
                    timestamp = now - 1000 * 60 * 46
                )
            )
            msgDao.insertMessage(
                MessageEntity(
                    conversationId = "conv_farhan_2",
                    text = "Sure bhai! Ami page owner ke notify korechi. Kichukkhoner moddhe tini apnar shathe direct kotha bolben. Dhonnobad apnar patience er jonno! 🙏",
                    senderType = SenderType.AI_ASSISTANT,
                    timestamp = now - 1000 * 60 * 45,
                    aiConfidence = 0.98f,
                    detectedIntent = "Human Agent Request",
                    isHumanHandoffTrigger = true
                )
            )
            notifDao.insertNotification(
                AppNotificationEntity(
                    title = "Human Assistance Requested",
                    description = "Farhan Kabir: Customer requested human assistance regarding parcel discrepancy.",
                    type = NotificationType.HANDOFF_REQUESTED,
                    conversationId = "conv_farhan_2",
                    timestamp = now - 1000 * 60 * 45
                )
            )

            // 3. Sadia Jahan (Pure Bangla inquiry)
            val c3 = ConversationEntity(
                conversationId = "conv_sadia_3",
                recipientId = "fb_sadia_201",
                recipientName = "Sadia Jahan",
                recipientAvatarUrl = "",
                label = ContactLabel.NEW_CONTACT,
                isAiActive = true,
                isHumanTakeover = false,
                lastMessageSnippet = "AI: হ্যালো! আমি Aria। আমাদের সকল প্রোডাক্ট...",
                lastMessageTimestamp = now - 1000 * 60 * 80,
                detectedLanguage = "Bangla",
                customerNotes = "Inquired about Dhanmondi store location."
            )
            convDao.insertOrUpdate(c3)

            msgDao.insertMessage(
                MessageEntity(
                    conversationId = "conv_sadia_3",
                    text = "আপনাদের শোরুমের ঠিকানা কোথায়? প্রোডাক্ট সরাসরি গিয়ে দেখা যাবে?",
                    senderType = SenderType.USER,
                    timestamp = now - 1000 * 60 * 82
                )
            )
            msgDao.insertMessage(
                MessageEntity(
                    conversationId = "conv_sadia_3",
                    text = "আমাদের প্রধান ডিসপ্লে ও পিকআপ পয়েন্ট: ধানমন্ডি ২৭, ঢাকা ১২০৯। প্রতিদিন সকাল ১০টা থেকে রাত ৮টা পর্যন্ত খোলা থাকে। 😊",
                    senderType = SenderType.AI_ASSISTANT,
                    timestamp = now - 1000 * 60 * 80,
                    aiConfidence = 0.95f,
                    detectedIntent = "Business Address"
                )
            )

            // 4. Dr. Mahbub Rahman (English inquiry)
            val c4 = ConversationEntity(
                conversationId = "conv_mahbub_4",
                recipientId = "fb_mahbub_881",
                recipientName = "Dr. Mahbub Rahman",
                recipientAvatarUrl = "",
                label = ContactLabel.IMPORTANT,
                isAiActive = true,
                isHumanTakeover = false,
                lastMessageSnippet = "AI: All our products are 100% genuine with...",
                lastMessageTimestamp = now - 1000 * 60 * 130,
                detectedLanguage = "English",
                customerNotes = "Interested in bulk order of smart desk lamps."
            )
            convDao.insertOrUpdate(c4)

            msgDao.insertMessage(
                MessageEntity(
                    conversationId = "conv_mahbub_4",
                    text = "Do you have official warranty and replacement policy on smart accessories?",
                    senderType = SenderType.USER,
                    timestamp = now - 1000 * 60 * 132
                )
            )
            msgDao.insertMessage(
                MessageEntity(
                    conversationId = "conv_mahbub_4",
                    text = "All our products are 100% genuine with verified quality checks, backed by a 7-day hassle-free replacement warranty. Would you like to know more about a specific model or color? 😊",
                    senderType = SenderType.AI_ASSISTANT,
                    timestamp = now - 1000 * 60 * 130,
                    aiConfidence = 0.94f,
                    detectedIntent = "Product Details"
                )
            )

            // Seed Friend Reviews (Meta compliant review list for leads/connections)
            reviewDao.insertReview(
                FriendReviewEntity(
                    contactName = "Sabbir Hossain",
                    messengerProfileId = "fb_sabbir_10",
                    mutualContext = "Sent inquiry regarding wholesale dealership. Requested owner personal follow-up.",
                    requestedAt = now - 1000 * 60 * 200,
                    status = ReviewStatus.PENDING
                )
            )
            reviewDao.insertReview(
                FriendReviewEntity(
                    contactName = "Nabila Khan",
                    messengerProfileId = "fb_nabila_22",
                    mutualContext = "Long-time customer requested connection on business profile.",
                    requestedAt = now - 1000 * 60 * 360,
                    status = ReviewStatus.APPROVED
                )
            )
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: AppRepository? = null

        fun getInstance(context: Context): AppRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = AppRepository(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
