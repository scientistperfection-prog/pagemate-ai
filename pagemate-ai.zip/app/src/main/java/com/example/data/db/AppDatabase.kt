package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.data.models.AppNotificationEntity
import com.example.data.models.ContactLabel
import com.example.data.models.ConversationEntity
import com.example.data.models.EmojiLevel
import com.example.data.models.FriendReviewEntity
import com.example.data.models.LanguageMode
import com.example.data.models.MemoryFactEntity
import com.example.data.models.MessageDeliveryStatus
import com.example.data.models.MessageEntity
import com.example.data.models.NotificationType
import com.example.data.models.PageConnectionEntity
import com.example.data.models.PersonalityConfigEntity
import com.example.data.models.ReplyLength
import com.example.data.models.ReviewStatus
import com.example.data.models.SenderType
import com.example.data.models.ToneStyle

class Converters {
    @TypeConverter
    fun fromContactLabel(label: ContactLabel): String = label.name

    @TypeConverter
    fun toContactLabel(value: String): ContactLabel = try {
        ContactLabel.valueOf(value)
    } catch (_: Exception) {
        ContactLabel.NEW_CONTACT
    }

    @TypeConverter
    fun fromSenderType(type: SenderType): String = type.name

    @TypeConverter
    fun toSenderType(value: String): SenderType = try {
        SenderType.valueOf(value)
    } catch (_: Exception) {
        SenderType.USER
    }

    @TypeConverter
    fun fromDeliveryStatus(status: MessageDeliveryStatus): String = status.name

    @TypeConverter
    fun toDeliveryStatus(value: String): MessageDeliveryStatus = try {
        MessageDeliveryStatus.valueOf(value)
    } catch (_: Exception) {
        MessageDeliveryStatus.DELIVERED
    }

    @TypeConverter
    fun fromLanguageMode(lang: LanguageMode): String = lang.name

    @TypeConverter
    fun toLanguageMode(value: String): LanguageMode = try {
        LanguageMode.valueOf(value)
    } catch (_: Exception) {
        LanguageMode.AUTO
    }

    @TypeConverter
    fun fromToneStyle(tone: ToneStyle): String = tone.name

    @TypeConverter
    fun toToneStyle(value: String): ToneStyle = try {
        ToneStyle.valueOf(value)
    } catch (_: Exception) {
        ToneStyle.FRIENDLY
    }

    @TypeConverter
    fun fromReplyLength(length: ReplyLength): String = length.name

    @TypeConverter
    fun toReplyLength(value: String): ReplyLength = try {
        ReplyLength.valueOf(value)
    } catch (_: Exception) {
        ReplyLength.SHORT
    }

    @TypeConverter
    fun fromEmojiLevel(level: EmojiLevel): String = level.name

    @TypeConverter
    fun toEmojiLevel(value: String): EmojiLevel = try {
        EmojiLevel.valueOf(value)
    } catch (_: Exception) {
        EmojiLevel.MODERATE
    }

    @TypeConverter
    fun fromNotificationType(type: NotificationType): String = type.name

    @TypeConverter
    fun toNotificationType(value: String): NotificationType = try {
        NotificationType.valueOf(value)
    } catch (_: Exception) {
        NotificationType.HANDOFF_REQUESTED
    }

    @TypeConverter
    fun fromReviewStatus(status: ReviewStatus): String = status.name

    @TypeConverter
    fun toReviewStatus(value: String): ReviewStatus = try {
        ReviewStatus.valueOf(value)
    } catch (_: Exception) {
        ReviewStatus.PENDING
    }
}

@Database(
    entities = [
        PageConnectionEntity::class,
        ConversationEntity::class,
        MessageEntity::class,
        MemoryFactEntity::class,
        PersonalityConfigEntity::class,
        AppNotificationEntity::class,
        FriendReviewEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun pageDao(): PageDao
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun memoryDao(): MemoryDao
    abstract fun personalityDao(): PersonalityDao
    abstract fun notificationDao(): NotificationDao
    abstract fun friendReviewDao(): FriendReviewDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "page_ai_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
