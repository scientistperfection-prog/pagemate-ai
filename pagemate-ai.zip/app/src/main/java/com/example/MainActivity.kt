package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ContactLabel
import com.example.ui.MainViewModel
import com.example.ui.dialogs.MetaConnectDialog
import com.example.ui.dialogs.NotificationsDialog
import com.example.ui.screens.AiControlPanelScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.ConversationsScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.MetaPolicyScreen
import com.example.ui.theme.AiPurple
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MetaBlue
import com.example.ui.theme.MetaLightBlue
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SuccessGreen

enum class AppTab(val title: String, val icon: ImageVector) {
    DASHBOARD("Dashboard", Icons.Default.Dashboard),
    MESSAGES("Messenger", Icons.Default.Forum),
    AI_CONTROL("AI Persona", Icons.Default.Tune),
    META_POLICY("Meta Safety", Icons.Default.Security)
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent(viewModel: MainViewModel) {
    val pageConnection by viewModel.pageConnection.collectAsState()
    val personality by viewModel.personalityConfig.collectAsState()
    val conversations by viewModel.filteredConversations.collectAsState()
    val unreadNotifs by viewModel.unreadNotifsCount.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val friendReviews by viewModel.friendReviews.collectAsState()
    val selectedFilter by viewModel.selectedFilterLabel.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    val activeConv by viewModel.activeConversation.collectAsState()
    val activeMessages by viewModel.activeMessages.collectAsState()
    val activeMemory by viewModel.activeMemory.collectAsState()
    val isAiThinking by viewModel.isAiThinking.collectAsState()
    val snackbarMsg by viewModel.snackbarMessage.collectAsState()

    var currentTab by remember { mutableStateOf(AppTab.DASHBOARD) }
    var showConnectDialog by remember { mutableStateOf(false) }
    var showNotifsDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMsg) {
        snackbarMsg?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearSnackbar()
        }
    }

    val needsHumanCount = conversations.count { it.label == ContactLabel.NEEDS_HUMAN_REPLY || it.isHumanTakeover }

    // If an individual conversation is open, show the ChatScreen
    if (activeConv != null) {
        ChatScreen(
            conversation = activeConv!!,
            messages = activeMessages,
            memoryFacts = activeMemory,
            isAiThinking = isAiThinking,
            isAiMemoryGloballyEnabled = personality?.isAiMemoryEnabled ?: true,
            onBack = { viewModel.clearActiveConversation() },
            onTakeOver = { viewModel.takeOverActiveConversation() },
            onReturnToAi = { viewModel.returnActiveConversationToAi() },
            onUpdateLabel = { viewModel.updateActiveConversationLabel(it) },
            onSendOwnerMessage = { viewModel.sendOwnerMessage(it) },
            onSimulateCustomerMessage = { viewModel.simulateIncomingCustomerMessage(it) },
            onAddMemoryFact = { cat, fact -> viewModel.addMemoryFact(cat, fact) },
            onDeleteMemoryFact = { viewModel.deleteMemoryFact(it) },
            onClearConversationMemory = { viewModel.clearActiveConversationMemory() },
            onDeleteConversation = { viewModel.deleteActiveConversation() },
            onToggleGlobalMemory = { viewModel.toggleAiMemory(it) }
        )
        return
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(MetaBlue)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "PageAI Assistant",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(if (pageConnection?.isConnected == true) SuccessGreen else ErrorRed)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (pageConnection?.isConnected == true) "Connected to ${pageConnection?.pageName}" else "Disconnected",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                },
                actions = {
                    BadgedBox(
                        badge = {
                            if (unreadNotifs > 0) {
                                Badge(containerColor = ErrorRed) {
                                    Text("$unreadNotifs")
                                }
                            }
                        }
                    ) {
                        IconButton(
                            onClick = { showNotifsDialog = true },
                            modifier = Modifier.testTag("notifications_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Notifications",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                AppTab.values().forEach { tab ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = tab },
                        icon = {
                            if (tab == AppTab.MESSAGES && needsHumanCount > 0) {
                                BadgedBox(
                                    badge = {
                                        Badge(containerColor = ErrorRed) {
                                            Text("$needsHumanCount")
                                        }
                                    }
                                ) {
                                    Icon(imageVector = tab.icon, contentDescription = tab.title)
                                }
                            } else {
                                Icon(imageVector = tab.icon, contentDescription = tab.title)
                            }
                        },
                        label = { Text(tab.title, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MetaBlue,
                            selectedTextColor = MetaBlue,
                            indicatorColor = MetaLightBlue
                        ),
                        modifier = Modifier.testTag("tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppTab.DASHBOARD -> DashboardScreen(
                    pageConnection = pageConnection,
                    personality = personality,
                    conversations = conversations,
                    onToggleBusyMode = { viewModel.toggleBusyMode(it) },
                    onToggleWelcomeSystem = { viewModel.toggleWelcomeSystem(it) },
                    onOpenConnectDialog = { showConnectDialog = true },
                    onSelectConversation = { viewModel.selectConversation(it) },
                    onSimulateMessage = { viewModel.simulateIncomingCustomerMessage(it) }
                )

                AppTab.MESSAGES -> ConversationsScreen(
                    conversations = conversations,
                    selectedFilter = selectedFilter,
                    searchQuery = searchQuery,
                    onFilterSelected = { viewModel.selectedFilterLabel.value = it },
                    onSearchChanged = { viewModel.searchQuery.value = it },
                    onSelectConversation = { viewModel.selectConversation(it) }
                )

                AppTab.AI_CONTROL -> AiControlPanelScreen(
                    currentConfig = personality,
                    onSaveConfig = { viewModel.updatePersonalityConfig(it) }
                )

                AppTab.META_POLICY -> MetaPolicyScreen(
                    friendReviews = friendReviews,
                    onUpdateReviewStatus = { id, status -> viewModel.updateReviewStatus(id, status) },
                    onClearAllData = { viewModel.clearAllData() }
                )
            }
        }
    }

    if (showConnectDialog) {
        MetaConnectDialog(
            currentConnection = pageConnection,
            onDismiss = { showConnectDialog = false },
            onConnect = { pageId, name -> viewModel.reconnectFacebook(pageId, name) },
            onDisconnect = { viewModel.disconnectFacebook() }
        )
    }

    if (showNotifsDialog) {
        NotificationsDialog(
            notifications = notifications,
            onDismiss = { showNotifsDialog = false },
            onSelectConversation = { convId -> viewModel.selectConversation(convId) },
            onMarkAllRead = { viewModel.markNotificationsRead() }
        )
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
